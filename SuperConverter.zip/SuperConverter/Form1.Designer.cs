﻿namespace SuperConverter
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            label4 = new Label();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            label5 = new Label();
            button1 = new Button();
            label6 = new Label();
            label7 = new Label();
            button2 = new Button();
            comboBox3 = new ComboBox();
            label8 = new Label();
            comboBox4 = new ComboBox();
            label9 = new Label();
            textBox2 = new TextBox();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            button3 = new Button();
            comboBox5 = new ComboBox();
            label13 = new Label();
            comboBox6 = new ComboBox();
            label14 = new Label();
            textBox3 = new TextBox();
            label15 = new Label();
            label16 = new Label();
            dateTimePicker1 = new DateTimePicker();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(567, 27);
            label1.Name = "label1";
            label1.Size = new Size(262, 45);
            label1.TabIndex = 0;
            label1.Text = "SuperConverter";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(225, 122);
            label2.Name = "label2";
            label2.Size = new Size(136, 37);
            label2.TabIndex = 1;
            label2.Text = "Currency";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label3.Location = new Point(113, 188);
            label3.Name = "label3";
            label3.Size = new Size(99, 25);
            label3.TabIndex = 2;
            label3.Text = "Amount :";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(225, 188);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(179, 33);
            textBox1.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label4.Location = new Point(139, 244);
            label4.Name = "label4";
            label4.Size = new Size(71, 25);
            label4.TabIndex = 4;
            label4.Text = "From :";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "USD", "AED", "AFN", "ALL", "AMD", "ANG", "AOA", "ARS", "AUD", "AWG", "AZN", "BAM", "BBD", "BDT", "BGN", "BHD", "BIF", "BMD", "BND", "BOB", "BRL", "BSD", "BTN", "BWP", "BYN", "BZD", "CAD", "CDF", "CHF", "CLP", "CNY", "COP", "CRC", "CUP", "CVE", "CZK", "DJF", "DKK", "DOP", "DZD", "EGP", "ERN", "ETB", "EUR", "FJD", "FKP", "FOK", "GBP", "GEL", "GGP", "GHS", "GIP", "GNF", "GTQ", "GYD", "HKD", "HNL", "HRK", "HTG", "HUF", "IDR", "ILS", "IMP", "INR", "IQD", "IRR", "ISK", "JEP", "JMD", "JPY", "KES", "KGS", "KHR", "KMF", "KRW", "KWD", "KYD", "KZT", "LAK", "LBP", "LSL", "LYD", "MAD", "MDL", "MGA", "MKD", "MMK", "MNT", "MOP", "MRU", "MUR", "MVR", "MWK", "MXN", "MYR", "MZN", "NAD", "NGN", "NIO", "NOK", "NPR", "NZD", "OMR", "PAB", "PEN", "PGK", "PHP", "PKR", "PLN", "PYG", "QAR", "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", "SEK", "SGD", "SHP", "SLE", "SLL", "SOS", "SRD", "SSP", "STN", "SYP", "SZL", "THB", "TJS", "TMT", "TND", "TOP", "TRY", "TTD", "TVD", "TWD", "TZS", "UAH", "UGX", "UYU", "UZS", "VES", "VND", "VUV", "WST", "XAF", "XCD", "XDR", "XOF", "XPF", "YER", "ZAR", "ZMW" });
            comboBox1.Location = new Point(225, 245);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(179, 29);
            comboBox1.TabIndex = 5;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "USD", "AED", "AFN", "ALL", "AMD", "ANG", "AOA", "ARS", "AUD", "AWG", "AZN", "BAM", "BBD", "BDT", "BGN", "BHD", "BIF", "BMD", "BND", "BOB", "BRL", "BSD", "BTN", "BWP", "BYN", "BZD", "CAD", "CDF", "CHF", "CLP", "CNY", "COP", "CRC", "CUP", "CVE", "CZK", "DJF", "DKK", "DOP", "DZD", "EGP", "ERN", "ETB", "EUR", "FJD", "FKP", "FOK", "GBP", "GEL", "GGP", "GHS", "GIP", "GNF", "GTQ", "GYD", "HKD", "HNL", "HRK", "HTG", "HUF", "IDR", "ILS", "IMP", "INR", "IQD", "IRR", "ISK", "JEP", "JMD", "JPY", "KES", "KGS", "KHR", "KMF", "KRW", "KWD", "KYD", "KZT", "LAK", "LBP", "LSL", "LYD", "MAD", "MDL", "MGA", "MKD", "MMK", "MNT", "MOP", "MRU", "MUR", "MVR", "MWK", "MXN", "MYR", "MZN", "NAD", "NGN", "NIO", "NOK", "NPR", "NZD", "OMR", "PAB", "PEN", "PGK", "PHP", "PKR", "PLN", "PYG", "QAR", "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", "SEK", "SGD", "SHP", "SLE", "SLL", "SOS", "SRD", "SSP", "STN", "SYP", "SZL", "THB", "TJS", "TMT", "TND", "TOP", "TRY", "TTD", "TVD", "TWD", "TZS", "UAH", "UGX", "UYU", "UZS", "VES", "VND", "VUV", "WST", "XAF", "XCD", "XDR", "XOF", "XPF", "YER", "ZAR", "ZMW" });
            comboBox2.Location = new Point(225, 313);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(179, 29);
            comboBox2.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label5.Location = new Point(152, 312);
            label5.Name = "label5";
            label5.Size = new Size(47, 25);
            label5.TabIndex = 6;
            label5.Text = "To :";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(254, 371);
            button1.Name = "button1";
            button1.Size = new Size(124, 29);
            button1.TabIndex = 8;
            button1.Text = "Convert";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(127, 440);
            label6.Name = "label6";
            label6.Size = new Size(85, 30);
            label6.TabIndex = 9;
            label6.Text = "Result :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(581, 433);
            label7.Name = "label7";
            label7.Size = new Size(85, 30);
            label7.TabIndex = 18;
            label7.Text = "Result :";
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(706, 371);
            button2.Name = "button2";
            button2.Size = new Size(124, 29);
            button2.TabIndex = 17;
            button2.Text = "Convert";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // comboBox3
            // 
            comboBox3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Celsius", "Fahrenheit", "Kelvin" });
            comboBox3.Location = new Point(679, 301);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(179, 29);
            comboBox3.TabIndex = 16;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label8.Location = new Point(606, 301);
            label8.Name = "label8";
            label8.Size = new Size(47, 25);
            label8.TabIndex = 15;
            label8.Text = "To :";
            // 
            // comboBox4
            // 
            comboBox4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "Celsius", "Fahrenheit", "Kelvin" });
            comboBox4.Location = new Point(679, 244);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(179, 29);
            comboBox4.TabIndex = 14;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label9.Location = new Point(595, 248);
            label9.Name = "label9";
            label9.Size = new Size(71, 25);
            label9.TabIndex = 13;
            label9.Text = "From :";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(679, 177);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(179, 33);
            textBox2.TabIndex = 12;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label10.Location = new Point(567, 177);
            label10.Name = "label10";
            label10.Size = new Size(99, 25);
            label10.TabIndex = 11;
            label10.Text = "Amount :";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Black", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(611, 122);
            label11.Name = "label11";
            label11.Size = new Size(189, 37);
            label11.TabIndex = 10;
            label11.Text = "Temperature";
            label11.Click += label11_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(989, 432);
            label12.Name = "label12";
            label12.Size = new Size(85, 30);
            label12.TabIndex = 27;
            label12.Text = "Result :";
            label12.Click += label12_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(1109, 371);
            button3.Name = "button3";
            button3.Size = new Size(124, 29);
            button3.TabIndex = 26;
            button3.Text = "Convert";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // comboBox5
            // 
            comboBox5.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            comboBox5.FormattingEnabled = true;
            comboBox5.Items.AddRange(new object[] { "meter", "kilometer", "centimeter", "inch", "foot", "yard" });
            comboBox5.Location = new Point(1073, 308);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(179, 29);
            comboBox5.TabIndex = 25;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label13.Location = new Point(1000, 301);
            label13.Name = "label13";
            label13.Size = new Size(47, 25);
            label13.TabIndex = 24;
            label13.Text = "To :";
            // 
            // comboBox6
            // 
            comboBox6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            comboBox6.FormattingEnabled = true;
            comboBox6.Items.AddRange(new object[] { "meter", "kilometer", "centimeter", "inch", "foot", "yard" });
            comboBox6.Location = new Point(1073, 245);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(179, 29);
            comboBox6.TabIndex = 23;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label14.Location = new Point(989, 249);
            label14.Name = "label14";
            label14.Size = new Size(71, 25);
            label14.TabIndex = 22;
            label14.Text = "From :";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(1073, 177);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(179, 33);
            textBox3.TabIndex = 21;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold);
            label15.Location = new Point(961, 177);
            label15.Name = "label15";
            label15.Size = new Size(99, 25);
            label15.TabIndex = 20;
            label15.Text = "Amount :";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Black", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.Location = new Point(1080, 122);
            label16.Name = "label16";
            label16.Size = new Size(86, 37);
            label16.TabIndex = 19;
            label16.Text = "Units";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(139, 45);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 28;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1375, 624);
            Controls.Add(dateTimePicker1);
            Controls.Add(label12);
            Controls.Add(button3);
            Controls.Add(comboBox5);
            Controls.Add(label13);
            Controls.Add(comboBox6);
            Controls.Add(label14);
            Controls.Add(textBox3);
            Controls.Add(label15);
            Controls.Add(label16);
            Controls.Add(label7);
            Controls.Add(button2);
            Controls.Add(comboBox3);
            Controls.Add(label8);
            Controls.Add(comboBox4);
            Controls.Add(label9);
            Controls.Add(textBox2);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label6);
            Controls.Add(button1);
            Controls.Add(comboBox2);
            Controls.Add(label5);
            Controls.Add(comboBox1);
            Controls.Add(label4);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "SuperConverter";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private Label label4;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private Label label5;
        private Button button1;
        private Label label6;
        private Label label7;
        private Button button2;
        private ComboBox comboBox3;
        private Label label8;
        private ComboBox comboBox4;
        private Label label9;
        private TextBox textBox2;
        private Label label10;
        private Label label11;
        private Label label12;
        private Button button3;
        private ComboBox comboBox5;
        private Label label13;
        private ComboBox comboBox6;
        private Label label14;
        private TextBox textBox3;
        private Label label15;
        private Label label16;
        private DateTimePicker dateTimePicker1;
    }
}
